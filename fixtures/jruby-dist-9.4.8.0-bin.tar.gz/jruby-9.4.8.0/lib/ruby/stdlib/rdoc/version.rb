module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.4.1.1'

end
