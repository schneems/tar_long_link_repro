# frozen_string_literal: true

module SubSpawn
	VERSION = "0.1.1"
end
