class IO::ConsoleMode
  VERSION = "0.7.2"
end
